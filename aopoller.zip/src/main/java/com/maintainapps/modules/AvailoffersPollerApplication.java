package com.maintainapps.modules;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvailoffersPollerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvailoffersPollerApplication.class, args);
	}

}
